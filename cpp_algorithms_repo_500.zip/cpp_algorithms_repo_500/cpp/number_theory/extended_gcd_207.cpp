// extended_gcd_207.cpp
// Category: number_theory
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

long long gcd(long long a, long long b){ while(b){ long long t=b; b=a%b; a=t;} return llabs(a); }
int main(){ cout<<gcd(48,18)<<"\n"; return 0; }
