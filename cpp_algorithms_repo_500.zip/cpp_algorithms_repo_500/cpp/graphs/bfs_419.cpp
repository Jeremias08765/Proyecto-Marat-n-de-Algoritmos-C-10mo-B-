// bfs_419.cpp
// Category: graphs
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

void demo_graph_search() {
    vector<vector<int>> g = {{1,2},{0,3},{0,3},{1,2}};
    vector<int> vis(g.size(),0);
    queue<int>q; q.push(0); vis[0]=1;
    while(!q.empty()){
        int v=q.front(); q.pop(); cout<<v<<' ';
        for(int nei:g[v]) if(!vis[nei]){vis[nei]=1; q.push(nei);}
    }
    cout<<"\n";
}
int main(){ demo_graph_search(); return 0; }
