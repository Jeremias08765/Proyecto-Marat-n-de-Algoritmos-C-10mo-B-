// tarjan_120.cpp
// Category: graphs
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

// Placeholder for tarjan_120. Replace with full implementation as needed.
void demo() { cout << "Running tarjan_120 demo\n"; }
int main() { demo(); return 0; }
