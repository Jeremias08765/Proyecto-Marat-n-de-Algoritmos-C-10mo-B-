// dijkstra_003.cpp
// Category: graphs
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

using pii = pair<int,int>;
void demo_dijkstra(){
    int n=4;
    vector<vector<pair<int,int>>> adj(n);
    adj[0].push_back({1,1}); adj[0].push_back({2,4});
    adj[1].push_back({2,2}); adj[1].push_back({3,6});
    vector<int> dist(n, 1e9); dist[0]=0;
    priority_queue<pii, vector<pii>, greater<pii>> pq; pq.push({0,0});
    while(!pq.empty()){
        auto [d,u]=pq.top(); pq.pop();
        if (d!=dist[u]) continue;
        for(auto [v,w]:adj[u]) if(dist[v]>d+w){ dist[v]=d+w; pq.push({dist[v],v}); }
    }
    for(int x:dist) cout<<x<<' '; cout<<"\n";
}
int main(){ demo_dijkstra(); return 0; }
