// bubble_sort_391.cpp
// Category: sorting
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

vector<int> bubble_sort(vector<int> a) {
    int n = a.size();
    for (int i = 0; i < n; ++i) {
        bool swapped = false;
        for (int j = 0; j + 1 < n - i; ++j) {
            if (a[j] > a[j+1]) { swap(a[j], a[j+1]); swapped = true; }
        }
        if (!swapped) break;
    }
    return a;
}
int main(){ vector<int> a={5,2,3,1}; auto b=bubble_sort(a); for(int x:b) cout<<x<<' '; cout<<"\n"; return 0; }
