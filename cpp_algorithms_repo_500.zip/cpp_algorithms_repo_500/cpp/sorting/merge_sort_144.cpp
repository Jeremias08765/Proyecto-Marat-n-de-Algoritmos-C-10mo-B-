// merge_sort_144.cpp
// Category: sorting
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

vector<int> merge_sort(vector<int> a) {
    if (a.size() <= 1) return a;
    int m = a.size()/2;
    vector<int> L(a.begin(), a.begin()+m), R(a.begin()+m,a.end());
    L = merge_sort(L); R = merge_sort(R);
    vector<int> res; int i=0,j=0;
    while(i<(int)L.size() && j<(int)R.size()){
        if(L[i]<=R[j]) res.push_back(L[i++]); else res.push_back(R[j++]);
    }
    while(i<(int)L.size()) res.push_back(L[i++]);
    while(j<(int)R.size()) res.push_back(R[j++]);
    return res;
}
int main(){ vector<int> a={4,1,3,2}; auto b=merge_sort(a); for(int x:b) cout<<x<<' '; cout<<"\n"; return 0; }
