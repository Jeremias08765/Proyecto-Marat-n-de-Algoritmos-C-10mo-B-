// lcs_030.cpp
// Category: dp
// Simple example implementation/demo

#include <bits/stdc++.h>
using namespace std;

int knapsack01(const vector<int>& val, const vector<int>& wt, int W) {
    int n = val.size();
    vector<int> dp(W+1,0);
    for(int i=0;i<n;i++) for(int w=W; w>=wt[i]; w--) dp[w]=max(dp[w], dp[w-wt[i]]+val[i]);
    return dp[W];
}
int main(){ cout<<knapsack01({60,100,120},{10,20,30},50)<<"\n"; return 0; }
