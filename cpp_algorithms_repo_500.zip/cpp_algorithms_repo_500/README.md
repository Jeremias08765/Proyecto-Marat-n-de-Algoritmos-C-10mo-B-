# C++ Algorithms Repository (500 .cpp files)

This repository contains 500 small C++ algorithm implementations and templates. They're organized into category folders under `cpp/`. Each file is a standalone `.cpp` with a simple `main()` demonstrating usage.

Generated on 2025-10-20.

Use these for learning, practice, or as starting points. Feel free to reorganize, add tests, or improve implementations.
